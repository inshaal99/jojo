// Footer year
document.getElementById('year').textContent = new Date().getFullYear();

// Mobile nav toggle
const menuToggle = document.getElementById('menuToggle');
const mobileNav = document.getElementById('mobileNav');

menuToggle.addEventListener('click', () => {
  const isOpen = mobileNav.classList.toggle('is-open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
});

mobileNav.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => {
    mobileNav.classList.remove('is-open');
    menuToggle.setAttribute('aria-expanded', 'false');
  });
});

// Grid overlay toggle — a nod to the underlying grid system every layout here is built on
const gridToggle = document.getElementById('gridToggle');
const gridOverlay = document.getElementById('gridOverlay');
const gridLabel = gridToggle.querySelector('span:not(.grid-toggle-icon)');

gridToggle.addEventListener('click', () => {
  const isVisible = gridOverlay.classList.toggle('is-visible');
  gridToggle.setAttribute('aria-pressed', String(isVisible));
  gridLabel.textContent = isVisible ? 'Hide grid' : 'Show grid';
});
