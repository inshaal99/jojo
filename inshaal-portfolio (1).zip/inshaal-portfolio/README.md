# Inshaal — Graphic Design Portfolio

A clean, minimal one-page portfolio site. Plain HTML/CSS/JS — no build step, so it works directly on GitHub Pages for free.

## Files

- `index.html` — page content
- `styles.css` — all styling
- `script.js` — mobile menu + the "show grid" toggle
- `images/` — the 8 Flavor Street project photos used in the Work section

## Host it free on GitHub Pages

1. **Create a GitHub account** at github.com if you don't have one.
2. **Create a new repository**
   - Click the "+" in the top right → "New repository"
   - Name it `inshaal-portfolio` (or anything you like)
   - Set it to **Public**
   - Click "Create repository"
3. **Upload these files**
   - On the repository page, click "Add file" → "Upload files"
   - Drag in `index.html`, `styles.css`, `script.js`, **and the whole `images` folder**
   - GitHub will keep the folder structure as long as you drag the folder itself, not just the files inside it
   - Click "Commit changes"
4. **Turn on Pages**
   - Go to the repository's **Settings** tab
   - Click **Pages** in the left sidebar
   - Under "Branch," choose `main` and folder `/ (root)`, then **Save**
5. **Visit your site**
   - After a minute or two, GitHub shows your live URL at the top of the Pages settings, usually:
     `https://YOUR-USERNAME.github.io/inshaal-portfolio/`

Any time you edit a file in the repo (or re-upload it), the live site updates automatically within a minute or so.

## Customizing

- **Add more projects**: each project in `index.html` is inside `<article class="work-card">`, with an `<img src="images/your-file.jpg">` inside it. Drop a new image into `images/`, then copy an existing `<article class="work-card">` block and update the `src`, `alt`, and text.
- **Colors**: edit the values at the top of `styles.css` under `:root` (`--accent` is the blue).
- **Text**: all copy (hero, about, services, contact) lives directly in `index.html` — just edit it in place.
- **Contact info**: your email and phone are already wired into the Contact section and are clickable (`mailto:` / `tel:`).

## Optional: custom domain

If you buy a domain later, add a `CNAME` file to the repo with your domain name in it, then point your domain's DNS at GitHub Pages (GitHub's docs walk through the exact records to add).
